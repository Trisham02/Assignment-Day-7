﻿
namespace Calculator2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.num1 = new System.Windows.Forms.Button();
            this.num2 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.num5 = new System.Windows.Forms.Button();
            this.num7 = new System.Windows.Forms.Button();
            this.num8 = new System.Windows.Forms.Button();
            this.numdot = new System.Windows.Forms.Button();
            this.num0 = new System.Windows.Forms.Button();
            this.num3 = new System.Windows.Forms.Button();
            this.num6 = new System.Windows.Forms.Button();
            this.num9 = new System.Windows.Forms.Button();
            this.bequ = new System.Windows.Forms.Button();
            this.bC = new System.Windows.Forms.Button();
            this.badd = new System.Windows.Forms.Button();
            this.bsub = new System.Windows.Forms.Button();
            this.bmul = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.bCE = new System.Windows.Forms.Button();
            this.TextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // num1
            // 
            this.num1.Location = new System.Drawing.Point(39, 65);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(75, 23);
            this.num1.TabIndex = 0;
            this.num1.Text = "1";
            this.num1.UseVisualStyleBackColor = true;
            this.num1.Click += new System.EventHandler(this.num1_Click);
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(141, 65);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(75, 23);
            this.num2.TabIndex = 1;
            this.num2.Text = "2";
            this.num2.UseVisualStyleBackColor = true;
            this.num2.Click += new System.EventHandler(this.num2_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(42, 111);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(72, 22);
            this.b4.TabIndex = 2;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.button3_Click);
            // 
            // num5
            // 
            this.num5.Location = new System.Drawing.Point(141, 111);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(75, 23);
            this.num5.TabIndex = 3;
            this.num5.Text = "5";
            this.num5.UseVisualStyleBackColor = true;
            this.num5.Click += new System.EventHandler(this.button4_Click);
            // 
            // num7
            // 
            this.num7.Location = new System.Drawing.Point(42, 160);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(75, 23);
            this.num7.TabIndex = 4;
            this.num7.Text = "7";
            this.num7.UseVisualStyleBackColor = true;
            this.num7.Click += new System.EventHandler(this.num7_Click);
            // 
            // num8
            // 
            this.num8.Location = new System.Drawing.Point(161, 160);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(75, 23);
            this.num8.TabIndex = 5;
            this.num8.Text = "8";
            this.num8.UseVisualStyleBackColor = true;
            this.num8.Click += new System.EventHandler(this.num8_Click);
            // 
            // numdot
            // 
            this.numdot.Location = new System.Drawing.Point(161, 223);
            this.numdot.Name = "numdot";
            this.numdot.Size = new System.Drawing.Size(75, 23);
            this.numdot.TabIndex = 6;
            this.numdot.Text = ".";
            this.numdot.UseVisualStyleBackColor = true;
            this.numdot.Click += new System.EventHandler(this.numdot_Click);
            // 
            // num0
            // 
            this.num0.Location = new System.Drawing.Point(51, 213);
            this.num0.Name = "num0";
            this.num0.Size = new System.Drawing.Size(75, 23);
            this.num0.TabIndex = 7;
            this.num0.Text = "0";
            this.num0.UseVisualStyleBackColor = true;
            this.num0.Click += new System.EventHandler(this.num0_Click);
            // 
            // num3
            // 
            this.num3.Location = new System.Drawing.Point(254, 65);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(75, 23);
            this.num3.TabIndex = 8;
            this.num3.Text = "3";
            this.num3.UseVisualStyleBackColor = true;
            this.num3.Click += new System.EventHandler(this.num3_Click);
            // 
            // num6
            // 
            this.num6.Location = new System.Drawing.Point(254, 111);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(75, 23);
            this.num6.TabIndex = 9;
            this.num6.Text = "6";
            this.num6.UseVisualStyleBackColor = true;
            this.num6.Click += new System.EventHandler(this.num6_Click);
            // 
            // num9
            // 
            this.num9.Location = new System.Drawing.Point(271, 160);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(75, 23);
            this.num9.TabIndex = 10;
            this.num9.Text = "9";
            this.num9.UseVisualStyleBackColor = true;
            this.num9.Click += new System.EventHandler(this.num9_Click);
            // 
            // bequ
            // 
            this.bequ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bequ.Location = new System.Drawing.Point(271, 213);
            this.bequ.Name = "bequ";
            this.bequ.Size = new System.Drawing.Size(75, 33);
            this.bequ.TabIndex = 11;
            this.bequ.Text = "=";
            this.bequ.UseVisualStyleBackColor = true;
            this.bequ.Click += new System.EventHandler(this.bequ_Click);
            // 
            // bC
            // 
            this.bC.Location = new System.Drawing.Point(176, 273);
            this.bC.Name = "bC";
            this.bC.Size = new System.Drawing.Size(75, 23);
            this.bC.TabIndex = 12;
            this.bC.Text = "C";
            this.bC.UseVisualStyleBackColor = true;
            this.bC.Click += new System.EventHandler(this.bC_Click);
            // 
            // badd
            // 
            this.badd.Location = new System.Drawing.Point(392, 91);
            this.badd.Name = "badd";
            this.badd.Size = new System.Drawing.Size(75, 23);
            this.badd.TabIndex = 13;
            this.badd.Text = "+";
            this.badd.UseVisualStyleBackColor = true;
            this.badd.Click += new System.EventHandler(this.badd_Click);
            // 
            // bsub
            // 
            this.bsub.Location = new System.Drawing.Point(414, 138);
            this.bsub.Name = "bsub";
            this.bsub.Size = new System.Drawing.Size(75, 23);
            this.bsub.TabIndex = 14;
            this.bsub.Text = "-";
            this.bsub.UseVisualStyleBackColor = true;
            this.bsub.Click += new System.EventHandler(this.bsub_Click);
            // 
            // bmul
            // 
            this.bmul.Location = new System.Drawing.Point(414, 186);
            this.bmul.Name = "bmul";
            this.bmul.Size = new System.Drawing.Size(75, 23);
            this.bmul.TabIndex = 15;
            this.bmul.Text = "*";
            this.bmul.UseVisualStyleBackColor = true;
            this.bmul.Click += new System.EventHandler(this.bmul_Click);
            // 
            // bdiv
            // 
            this.bdiv.Location = new System.Drawing.Point(431, 237);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(75, 23);
            this.bdiv.TabIndex = 16;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = true;
            this.bdiv.Click += new System.EventHandler(this.bdiv_Click);
            // 
            // bCE
            // 
            this.bCE.Location = new System.Drawing.Point(271, 284);
            this.bCE.Name = "bCE";
            this.bCE.Size = new System.Drawing.Size(75, 23);
            this.bCE.TabIndex = 17;
            this.bCE.Text = "CE";
            this.bCE.UseVisualStyleBackColor = true;
            this.bCE.Click += new System.EventHandler(this.bCE_Click);
            // 
            // TextBox
            // 
            this.TextBox.Location = new System.Drawing.Point(161, 12);
            this.TextBox.Name = "TextBox";
            this.TextBox.Size = new System.Drawing.Size(235, 20);
            this.TextBox.TabIndex = 18;
            this.TextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TextBox);
            this.Controls.Add(this.bCE);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.bmul);
            this.Controls.Add(this.bsub);
            this.Controls.Add(this.badd);
            this.Controls.Add(this.bC);
            this.Controls.Add(this.bequ);
            this.Controls.Add(this.num9);
            this.Controls.Add(this.num6);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.num0);
            this.Controls.Add(this.numdot);
            this.Controls.Add(this.num8);
            this.Controls.Add(this.num7);
            this.Controls.Add(this.num5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button num1;
        private System.Windows.Forms.Button num2;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button num5;
        private System.Windows.Forms.Button num7;
        private System.Windows.Forms.Button num8;
        private System.Windows.Forms.Button numdot;
        private System.Windows.Forms.Button num0;
        private System.Windows.Forms.Button num3;
        private System.Windows.Forms.Button num6;
        private System.Windows.Forms.Button num9;
        private System.Windows.Forms.Button bequ;
        private System.Windows.Forms.Button bC;
        private System.Windows.Forms.Button badd;
        private System.Windows.Forms.Button bsub;
        private System.Windows.Forms.Button bmul;
        private System.Windows.Forms.Button bdiv;
        private System.Windows.Forms.Button bCE;
        private System.Windows.Forms.TextBox TextBox;
    }
}

