﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator2
{
    public partial class Form1 : Form
    {
        public string var1 = "";
        public string var2 = "";
        public string op = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            


        
        }

        private void num1_Click(object sender, EventArgs e)
        {
            var1 = var1 + num1.Text; // To concat numbers
            TextBox.Text = var1;


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void num2_Click(object sender, EventArgs e)
        {
            var1 = var1 + num2.Text; // To concat numbers
            TextBox.Text = var1;

        }

        private void num3_Click(object sender, EventArgs e)
        {
            var1 = var1 + num3.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void num6_Click(object sender, EventArgs e)
        {
            var1 = var1 + num6.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void num7_Click(object sender, EventArgs e)
        {
            var1 = var1 + num7.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void num8_Click(object sender, EventArgs e)
        {
            var1 = var1 + num8.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void num9_Click(object sender, EventArgs e)
        {
            var1 = var1 + num9.Text; // To concat numbers
            TextBox.Text = var1;
        }
        private void num4_Click(object sender, EventArgs e)
        {
            var1 = var1 + b4.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void num5_Click(object sender, EventArgs e)
        {
            var1 = var1 + num5.Text; // To concat numbers
            TextBox.Text = var1;
        }

        public string res;
        private void bequ_Click(object sender, EventArgs e)
        {
            if (op == "+")
            {
                res = (Convert.ToDecimal(var1) + Convert.ToDecimal(var2)).ToString();
                TextBox.Text = res;
            }
            if (op == "-")
            {
                res = (Convert.ToDecimal(var2) - Convert.ToDecimal(var1)).ToString();
                TextBox.Text = res;
            }
            if (op == "*")
            {
                res = (Convert.ToDecimal(var1) * Convert.ToDecimal(var2)).ToString();
                TextBox.Text = res;
            }
            if (op == "/")
            {
                res = (Convert.ToDecimal(var2) / Convert.ToDecimal(var1)).ToString();
                TextBox.Text = res;
            }
        }


        private void badd_Click(object sender, EventArgs e)
        {
            op = badd.Text.ToString();
            var2 = var1;
            var1 = "";
            TextBox.Text = op;
        }

        private void bsub_Click(object sender, EventArgs e)
        {
            op = bsub.Text.ToString();
            var2 = var1;
            var1 = "";
            TextBox.Text = op;
        }

        private void bmul_Click(object sender, EventArgs e)
        {
            op = bmul.Text.ToString();
            var2 = var1;
            var1 = "";
            TextBox.Text = op;
        }

        private void bdiv_Click(object sender, EventArgs e)
        {
            op = bdiv.Text.ToString();
            var2 = var1;
            var1 = "";
            TextBox.Text = op;
        }

        private void num0_Click(object sender, EventArgs e)
        {
            var1 = var1 + num0.Text; // To concat numbers
            TextBox.Text = var1;
        }

        private void numdot_Click(object sender, EventArgs e)
        {
            var1 = var1 + numdot.Text;
            TextBox.Text = var1;

        }

        private void bC_Click(object sender, EventArgs e)
        {
            var1 = "";
            var2 = "";
            op = "";
            TextBox.Text = "";
            res = "";
        }

        private void bCE_Click(object sender, EventArgs e)
        {
            var1 = var1.Remove(var1.Length - 1, 1);
            TextBox.Text = var1;

        }
    }
}
